/** @file   HtkWinService.cpp
*   @note HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
*   @brief 	HtkWinService ��ʵ��
*   @note	
*   <version>       <time>          <author>        <desc>
*      1.0         2015/8/13        zhuweiping          found                                                   
*/
#include <htk.h>
#include "HtkWinService.h"
#include <stdio.h>

VOID WINAPI ServiceMain(DWORD dwArgc, LPSTR *lpszArgv);
VOID WINAPI ServiceHandler(DWORD fdwControl);
SERVICE_STATUS_HANDLE   hServiceStatusHandle; 
SERVICE_STATUS          ServiceStatus; 

std::string CHtkWinService::m_strName;      ///< service name
StartServer CHtkWinService::m_fnStart;
StopServer CHtkWinService::m_fnStop;
CHtkWinService::CHtkWinService(StartServer fnStart, StopServer fnStop, const char* szSvrName, const char* szSvrDisplay)
:m_strDisplay(szSvrDisplay)
{
    char szModuleFile[256] = {0};
    if( 0 < GetModuleFileName(NULL, szModuleFile, 256))
    {
        m_strFileName = szModuleFile;
    }
    m_fnStart = fnStart;
    m_fnStop = fnStop;
    m_strName = szSvrName;
}

int CHtkWinService::Install()
{
    HTK_DBG("CHtkWinService::Install()");
    int iRet = HTK_EOK;
    SC_HANDLE schSCManager = NULL;
    SC_HANDLE schService = NULL;
    do 
    {
        if( m_strFileName.empty() || m_strName.empty() || m_strDisplay.empty() || (NULL == m_fnStart) || (NULL == m_fnStop) )
        {
            iRet = HTK_ENOT_INIT;
            break;
        }
        schSCManager = OpenSCManager( NULL, NULL, SC_MANAGER_CREATE_SERVICE); 
        if( NULL == schSCManager )
        {
            HTK_ERRM(HTK_LastErr(GetLastError()));
            iRet = HTK_ECALL_FUN_FAIL;
            break;
        }
        schService = CreateService
            ( 
            schSCManager,	/* SCManager database      */ 
            m_strName.c_str(),			/* name of service         */ 
            m_strDisplay.c_str(),			/* service name to display */ 
            SERVICE_ALL_ACCESS,        /* desired access          */ 
            SERVICE_WIN32_OWN_PROCESS|SERVICE_INTERACTIVE_PROCESS , /* service type            */ 
            SERVICE_AUTO_START,      /* start type              */ 
            SERVICE_ERROR_NORMAL,      /* error control type      */ 
            m_strFileName.c_str(),			/* service's binary        */ 
            NULL,                      /* no load ordering group  */ 
            NULL,                      /* no tag identifier       */ 
            NULL,                      /* no dependencies         */ 
            NULL,                      /* LocalSystem account     */ 
            NULL
            );                     /* no password             */ 
        if( NULL == schService )
        {
            HTK_ERRM(HTK_LastErr(GetLastError()));
            iRet = HTK_ECALL_FUN_FAIL;
        }
    } while (0);
    
    if( NULL != schService )
    {
        CloseServiceHandle(schService);
    }
    if ( NULL != schSCManager) 
    {
        CloseServiceHandle(schSCManager);
    }
    if( HTK_EOK != iRet )
    {
        HTK_ERRC(iRet);
    }
    return iRet;
}
int CHtkWinService::UnInstall()
{
    int iRet = HTK_EOK;
    SC_HANDLE schSCManager = NULL;
    SC_HANDLE schService = NULL;
    do 
    {
        if( m_strName.empty() )
        {
            iRet = HTK_ENOT_INIT;
            break;
        }
        schSCManager = OpenSCManager( NULL, NULL, SC_MANAGER_ALL_ACCESS);
        if( NULL == schSCManager )
        {
            HTK_ERRM(HTK_LastErr(GetLastError()));
            iRet = HTK_ECALL_FUN_FAIL;
            break;
        }
        schService = OpenService( schSCManager, m_strName.c_str(), SERVICE_ALL_ACCESS);
        if( NULL == schService )
        {
            HTK_ERRM(HTK_LastErr(GetLastError()));
            iRet = HTK_ECALL_FUN_FAIL;
            break;
        }
        if( FALSE == DeleteService(schService) )
        {
            HTK_ERRM(HTK_LastErr(GetLastError()));
            iRet = HTK_ECALL_FUN_FAIL;
        }
    } while (0);
    
    if( NULL != schService )
    {
        CloseServiceHandle(schService);
    }
    if ( NULL != schSCManager) 
    {
        CloseServiceHandle(schSCManager);
    }

    if( HTK_EOK != iRet )
    {
        HTK_ERRC(iRet);
    }

    return iRet;
}
int CHtkWinService::Run()
{
    int iRet = HTK_EOK;
    SC_HANDLE schSCManager = NULL;
    SC_HANDLE schService = NULL;
    do 
    {
        if( m_strName.empty() )
        {
            iRet = HTK_ENOT_INIT;
            break;
        }
        schSCManager = OpenSCManager( NULL, NULL, SC_MANAGER_ALL_ACCESS);
        if( NULL == schSCManager)
        {
            HTK_ERRM(HTK_LastErr(GetLastError()));
            iRet = HTK_ECALL_FUN_FAIL;
            break;
        }
        schService = OpenService( schSCManager, m_strName.c_str(), SERVICE_ALL_ACCESS);
        if( NULL == schSCManager)
        {
            HTK_ERRM(HTK_LastErr(GetLastError()));
            iRet = HTK_ECALL_FUN_FAIL;
            break;
        }
        if( FALSE == StartService(schService, 0, (const char**)NULL) )
        {
            HTK_ERRM(HTK_LastErr(GetLastError()));
            iRet = HTK_ECALL_FUN_FAIL;
        }
    } while (0);
    if( NULL != schService )
    {
        CloseServiceHandle(schService);
    }
    if ( NULL != schSCManager) 
    {
        CloseServiceHandle(schSCManager);
    }
    if( HTK_EOK != iRet )
    {
        HTK_ERRC(iRet);
    }
    return iRet;
}
int CHtkWinService::Stop()
{
    int iRet = HTK_EOK;
    SC_HANDLE schSCManager = NULL;
    SC_HANDLE schService = NULL;
    SERVICE_STATUS status;
    do 
    {
        if( m_strName.empty() )
        {
            iRet = HTK_ENOT_INIT;
            break;
        }
        schSCManager = OpenSCManager( NULL, NULL, SC_MANAGER_ALL_ACCESS);
        if( NULL == schSCManager)
        {
            HTK_ERRM(HTK_LastErr(GetLastError()));
            iRet = HTK_ECALL_FUN_FAIL;
            break;
        }
        schService = OpenService( schSCManager, m_strName.c_str(), SERVICE_ALL_ACCESS);
        if( NULL == schSCManager)
        {
            HTK_ERRM(HTK_LastErr(GetLastError()));
            iRet = HTK_ECALL_FUN_FAIL;
            break;
        }

        if( FALSE == ControlService(schService,SERVICE_CONTROL_STOP,&status) )
        {
            HTK_ERRM(HTK_LastErr(GetLastError()));
            iRet = HTK_ECALL_FUN_FAIL;
        }
    } while (0);
    if( NULL != schService )
    {
        CloseServiceHandle(schService);
    }
    if ( NULL != schSCManager) 
    {
        CloseServiceHandle(schSCManager);
    }
    if( HTK_EOK != iRet )
    {
        HTK_ERRC(iRet);
    }
    return iRet;
}


int CHtkWinService::Dispatch()
{
    int iRet = HTK_EOK;
    if( m_strName.empty() )
    {
        HTK_ERRC(HTK_ENOT_INIT);
        return HTK_ENOT_INIT;
    }
    char szName[256] = {0};
    sprintf(szName,m_strName.c_str());
    SERVICE_TABLE_ENTRY		lpServiceStartTable[] = 
    {
        {szName, ServiceMain},
        {NULL, NULL}
    };
    if(FALSE == StartServiceCtrlDispatcher(lpServiceStartTable))
    {
        HTK_ERRM(HTK_LastErr(GetLastError()));
        iRet = HTK_ECALL_FUN_FAIL;
    }
    return iRet;
}

BOOL WINAPI ControlHandler ( DWORD dwCtrlType )
{
    switch( dwCtrlType )
    {
    case CTRL_BREAK_EVENT:  // use Ctrl+C or Ctrl+Break to simulate
    case CTRL_C_EVENT:      // SERVICE_CONTROL_STOP in debug mode
        CHtkWinService::m_fnStop();
        return TRUE;
    }
    return FALSE;
}

int CHtkWinService::Debug(int argc, char** argv)
{
    SetConsoleCtrlHandler( ControlHandler, TRUE );
    CHtkWinService::m_fnStart(argc, argv);
    return HTK_EOK;
}


VOID WINAPI ServiceMain(DWORD dwArgc, LPSTR *lpszArgv)
{
    HTK_MSG("ServiceMain");
    ServiceStatus.dwServiceType        = SERVICE_WIN32; 
    ServiceStatus.dwCurrentState       = SERVICE_START_PENDING; 
    ServiceStatus.dwControlsAccepted   = SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN | SERVICE_ACCEPT_PAUSE_CONTINUE; 
    ServiceStatus.dwWin32ExitCode      = 0; 
    ServiceStatus.dwServiceSpecificExitCode = 0; 
    ServiceStatus.dwCheckPoint         = 0; 
    ServiceStatus.dwWaitHint           = 0; 

    hServiceStatusHandle = RegisterServiceCtrlHandler(CHtkWinService::m_strName.c_str(), ServiceHandler); 
    if (hServiceStatusHandle==0) 
    {
        HTK_ERRM(HTK_LastErr(GetLastError()));
        return; 
    } 

    // Initialization complete - report running status 
    ServiceStatus.dwCurrentState       = SERVICE_RUNNING; 
    ServiceStatus.dwCheckPoint         = 0; 
    ServiceStatus.dwWaitHint           = 0;  
    if(!SetServiceStatus(hServiceStatusHandle, &ServiceStatus)) 
    { 
        HTK_ERRM(HTK_LastErr(GetLastError()));
    } 
    CHtkWinService::m_fnStart(dwArgc, lpszArgv);
}

VOID WINAPI ServiceHandler(DWORD fdwControl)
{
    switch(fdwControl) 
    {
    case SERVICE_CONTROL_STOP:
    case SERVICE_CONTROL_SHUTDOWN:
        {
            CHtkWinService::m_fnStop();
            ServiceStatus.dwWin32ExitCode = 0; 
            ServiceStatus.dwCurrentState  = SERVICE_STOPPED; 
            ServiceStatus.dwCheckPoint    = 0; 
            ServiceStatus.dwWaitHint      = 0;
        }
        break; 
    case SERVICE_CONTROL_PAUSE:
        ServiceStatus.dwCurrentState = SERVICE_PAUSED; 
        break;
    case SERVICE_CONTROL_CONTINUE:
        ServiceStatus.dwCurrentState = SERVICE_RUNNING; 
        break;
    case SERVICE_CONTROL_INTERROGATE:
        break;
    default:
        HTK_ERRC(HTK_ENO_HANDLER);
        break;
    };
    if (!SetServiceStatus(hServiceStatusHandle,  &ServiceStatus)) 
    { 
        HTK_ERRM(HTK_LastErr(GetLastError()));
    } 
}
