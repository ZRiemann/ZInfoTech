
#include "../HtkTrace.h"
#include <stdlib.h>
#include "HtkStringUti.h"

int HTK_StrSplit(const std::string& strSrc, const std::string& strSplit, std::vector<std::string>& vDest, int iFlag)
{
    if( 1 == iFlag )
    {
        vDest.clear();
    }
    
    int iLen = strSplit.length();
    int iPos = 0;
    int iPos1 = strSrc.find(strSplit,iPos);
    if( strSrc.npos == iPos1 )
    {
        vDest.push_back(strSrc);
        return HTK_EOK;
    }
    if( iPos1 == iPos )
    {
        iPos += iLen;
    }
    while( strSrc.npos != (iPos1 = strSrc.find(strSplit,iPos)) )
    {
        vDest.push_back(strSrc.substr(iPos,iPos1-iPos));
        iPos = iPos1 + iLen;
    }
    iPos1 = strSrc.length();
    if( iPos1 != iPos )
    {
        vDest.push_back(strSrc.substr(iPos,iPos1-iPos));
    }
    return HTK_EOK;
}
int HTK_StrSplit(const std::string& strSrc, const std::string& strSplit, std::vector<int>& vDest, int iFlag)
{
    if( 1 == iFlag )
    {
        vDest.clear();
    }

    int iLen = strSplit.length();
    int iPos = 0;
    int iPos1 = strSrc.find(strSplit,iPos);
    if( strSrc.npos == iPos1 )
    {
        vDest.push_back(atoi(strSrc.c_str()));
        return HTK_EOK;
    }
    if( iPos1 == iPos )
    {
        iPos += iLen;
    }
    while( strSrc.npos != (iPos1 = strSrc.find(strSplit,iPos)) )
    {
        vDest.push_back(atoi(strSrc.substr(iPos,iPos1-iPos).c_str()));
        iPos = iPos1 + iLen;
    }
    iPos1 = strSrc.length();
    if( iPos1 != iPos )
    {
        vDest.push_back(atoi(strSrc.substr(iPos,iPos1-iPos).c_str()));
    }
    return HTK_EOK;
}