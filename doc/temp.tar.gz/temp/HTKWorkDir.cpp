#include <htk/utility/HTKWorkDir.h>
#include <Windows.h>
#include <string.h>

/** @fn		char* work_dir(char* dir_buf)
*   @param	char* dir_buf	[IN|OUT]	buffer of direction string
*   @param	int	  buf_size	[IN]		size of buffer
*   @return	char point of direction
*   @note	recommend dir_buf size is MAX_PATH 256
*/
char* HTK_WorkDir(char* pcDir, int iLen){
	char* pdest;
	::GetModuleFileNameA(NULL,pcDir,iLen);
	pdest = strrchr(pcDir,'\\');
    if(NULL != (int)pdest)
    {
        *(pdest+1) = '\0';
    }
	return pcDir;
}