#ifndef _HTK_SEMAPHORE_C_H_
#define _HTK_SEMAPHORE_C_H_

#ifdef __cplusplus
extern "C"{
#endif

#include "../HtkType.h"
#include "../HtkTrace.h"
#include <semaphore.h>
#include <time.h>
#include <sys/time.h>

int HTK_SemInit(sem_t* sem, int pshared, HTK_UINT value);
int HTK_SemWait(sem_t* sem);
//int HTK_SemPost(sem_t* sem);
int HTK_SemDestroy(sem_t* sem);
int HTK_SemTryWait(sem_t* sem);

int HTK_SemGetValue(sem_t* sem, int* sval);
int HTK_SemTimedWait(sem_t* sem, const struct timespec* abs_timeout);
#define HTK_SemPost(x) if( 0 != sem_post(x) ){HTK_ERRM("HTK_SemPost Failed.");}

#ifdef __cplusplus
}
#endif

#endif
