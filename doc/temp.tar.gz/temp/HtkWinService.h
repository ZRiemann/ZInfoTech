/** @file   HtkWinService.h
*   @note HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
*   @brief 	Windows Service wrapper
*   @note	
*   <version>       <time>          <author>        <desc>
*      1.0         2015/8/4        zhuweiping          found                                                   
*/
#ifndef _HTK_WIN_SERVICE_H_
#define _HTK_WIN_SERVICE_H_

#include "../HtkType.h"
#include <string>

typedef int (HTK_STDCALL *StartServer)(int argc, char** argv);
typedef int (HTK_STDCALL *StopServer)();

class CHtkWinService
{
public:
    CHtkWinService(StartServer fnStart, StopServer fnStop, const char* szSvrName, const char* szSvrDisplay);
    /** @fn     int Install()		
    *   @brief 	install win service
    *   @param	
    *	@return	HTK_EOK/HTK_E*
    *	@note
    */
    int Install();
    
    /** @fn		int UnInstall();
    *   @brief 	Uninstall win service
    *   @param	
    *	@return	HTK_EOK/HTK_E*
    *	@note
    */
    int UnInstall();

    /** @fn		int Run()
    *   @brief 	Run service
    *   @param	
    *	@return	HTK_EOK/HTK_E*
    *	@note
    */
    int Run();

    /** @fn		int Stop()
    *   @brief 	Stop service
    *   @param	
    *	@return	HTK_EOK/HTK_E*
    *	@note
    */
    int Stop();

    /** @fn		int Dispatch();
    *   @brief 	StartServiceCtrlDispatcher
    *   @param	
    *	@return	HTK_EOK/HTK_E*
    *	@note
    */
    int Dispatch();

    /** @fn		int Debug(int argc, char** argv);
    *   @brief 	run server Debug mode
    *   @param	[IN] int argc       An integer specifying how many arguments are passed to the program.
    *   @param  [IN] char** argv    An array of null-terminated strings.
    *	@return	HTK_EOK/HTK_E*
    *	@note
    */
    int Debug(int argc, char** argv);

    static std::string m_strName;       ///< service name
    static StartServer m_fnStart;       ///< service start call back
    static StopServer m_fnStop;         ///< service stop call back
protected:
    std::string m_strFileName;          ///< service file path
    std::string m_strDisplay;           ///< service display  
};

#endif
