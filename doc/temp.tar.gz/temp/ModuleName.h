#ifndef _HTK_MODULE_NAME_H_
#define _HTK_MODULE_NAME_H_

/** @fn		int HTK_ModuleName(char* path, char* name)
*   @brief 	get module file name
*   @param	char* path [OUT] absolute path name
*   @param  char* name [OUT] file name
*	@return	HTK_EOK/HTK_E*
*	@note
*   param null ignore param.
*/
int HTK_ModuleName(char* path, char* name);

#endif
