/** @file   HtkThread.cpp
*   @note HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
*   @brief 	�߳�ʵ����ͷ�ļ�

*   @author	Zhu Weiping
*   @date   2015/3/24

*   @note	
*/
#include "../HtkTrace.h"
#include "../thread/HtkThread.h"
#include "../thread/HtkSemaphore.h"
#include "../thread/HtkCritical.h"
#include <process.h>
#include <vector>
#include <stdlib.h>

typedef struct tagHtkThread
{
    HANDLE m_hThr;
    CHtkSemaphore m_sem;
    bool m_bDetach;
    HTK_UINT m_uiID;

    tagHtkThread():m_hThr(NULL),m_bDetach(false),m_uiID(0),m_sem(0,1)
    {

    }

    static std::vector<CHtkThread*> s_vThreads;    // buffer all threads for CancelAll().
    static CHtkCritical s_csThreads;               // s_vThread Mutex
    static int Push(CHtkThread* pt);
    static int Erase(CHtkThread* pt);
    
}HTK_THR_T;

std::vector<CHtkThread*> HTK_THR_T::s_vThreads;
CHtkCritical HTK_THR_T::s_csThreads;

int HTK_THR_T::Push(CHtkThread* pt)
{
    if(NULL == pt)
    {
        HTK_ERRC(HTK_EPARAM_0_POINTER);
        return HTK_EPARAM_0_POINTER;
    }
    CHtkCriticalLock oLck(&s_csThreads);
    s_vThreads.push_back(pt);
    return HTK_EOK;
}

int HTK_THR_T::Erase(CHtkThread* pt)
{
    int iRet = HTK_ENOT_FIND_OBJ;
    if( NULL == pt )
    {
        iRet = HTK_EPARAM_0_POINTER;
        HTK_ERRC(iRet);
    }
    else
    {
        CHtkCriticalLock oLck(&s_csThreads);
        if( s_vThreads.empty() )
        {
            return iRet;
        }
        for( std::vector<CHtkThread*>::iterator it = s_vThreads.begin(); it != s_vThreads.end(); it++)
        {
            if( pt == *it )
            {
                s_vThreads.erase(it);
                iRet = HTK_EOK;
                break;
            }
        }
    }
    return iRet;
}

#define m_pt ((HTK_THR_T*)m_imp)

CHtkThread::CHtkThread()
{
    m_imp = (void*)new(std::nothrow) HTK_THR_T;
}
CHtkThread::~CHtkThread()
{
    if( NULL != m_imp )
    {
        Cancel();
        Jion();
        delete ((HTK_THR_T*)m_imp);
        m_imp = NULL;
    }
}

int CHtkThread::Create(fnThrProc fnProc, void* param)
{
    int iRet = HTK_EOK;
    if( NULL != fnProc )
    {
        m_pt->m_hThr = (HANDLE)_beginthreadex(NULL,0,fnProc,param,0, &(m_pt->m_uiID));
        if( NULL == m_pt->m_hThr )
        {
            iRet = HTK_ECALL_FUN_FAIL;
            HTK_ERRC(iRet);
        }
        else
        {
            HTK_THR_T::Push(this);
            HTK_MSG("Thread:%08x Created.",m_pt->m_uiID);
        }
    }
    else
    {
        iRet = HTK_EPARAM_0_POINTER;
        HTK_ERRC(iRet);
    }
    return iRet;
}
int CHtkThread::Detach()
{
    int iRet = HTK_EOK;
    if( (NULL != m_pt) && (NULL != m_pt->m_hThr) )
    {
        if( FALSE == CloseHandle(m_pt->m_hThr) )
        {
            iRet = HTK_ECALL_FUN_FAIL;
            HTK_ERRC( iRet );
        }
        else
        {
            HTK_MSG("Thread:%08x Detached", m_pt->m_uiID);
            HTK_THR_T::Erase(this);
            m_pt->m_bDetach = true;
        }
    }
    else
    {
        iRet = HTK_ENOT_INIT;
    }
    return iRet;
}

int CHtkThread::Cancel()
{
    int iRet = HTK_EOK;
    iRet = HTK_THR_T::Erase(this);
    if( HTK_EOK == iRet || m_pt->m_bDetach )
    {
        iRet = m_pt->m_sem.Post(1);
        HTK_MSG("Thread:%08x Canceled.",m_pt->m_uiID);
    }
    return iRet;
}
int CHtkThread::Jion()
{
    int iRet = HTK_EOK;
    HTK_MSG("CAUTION: Jion Thread:%08x ...",m_pt->m_uiID);
    if( m_pt->m_bDetach )
    {
        HTK_MSG("Thread:%08x is a detached thread.",m_pt->m_uiID);
    }
    else
    {
        iRet = WaitForSingleObject(m_pt->m_hThr, INFINITE );
        if( WAIT_OBJECT_0 == iRet )
        {
            iRet = HTK_EOK;
        }
        else
        {
            iRet = HTK_ECALL_FUN_FAIL;
            HTK_ERRC(iRet);
        }
        CloseHandle(m_pt->m_hThr);
    }
    HTK_MSG("CAUTION: Jion Thread:%08x OK.",m_pt->m_uiID);
    return iRet;
}
int CHtkThread::Exit(HTK_THR_RET ret)
{
    ExitThread( ret );
    return HTK_EOK;
}

int CHtkThread::Wait(int ms)
{
    return m_pt->m_sem.Wait(ms);
}
int CHtkThread::CancelAll()
{
    CHtkCriticalLock oLck(&HTK_THR_T::s_csThreads);
    
    while( HTK_THR_T::s_vThreads.size() )
    {
        HTK_THR_T* pt = (HTK_THR_T*)( HTK_THR_T::s_vThreads.back()->m_imp);
        HTK_MSG("Thread:%08x Canceled.",pt->m_uiID);
        pt->m_sem.Post(1);
        HTK_THR_T::s_vThreads.pop_back();
    }
    return HTK_EOK;
}