#include "../HtkError.h"
#include "../HtkTrace.h"
#include <wininet.h>  
#pragma comment(lib,"wininet") 
#include "HtkWininet.h"

int HTK_DownUrl(const char* szUrl, char** ppbyBuf, int* piBufLen)
{
    HINTERNET   hSession=InternetOpen(NULL,INTERNET_OPEN_TYPE_PRECONFIG,NULL,NULL,0);
    HTK_VERIFY_EQUAL(NULL,hSession,ECALL_FUN_FAIL);
    HINTERNET   hConnection=InternetOpenUrl(hSession,szUrl,NULL,0,0,0); 
    HTK_VERIFY_EQUAL(NULL,hConnection,ECALL_FUN_FAIL);

    int iSize = 1024*1024*3;
    char* pbyBuf = (char*)malloc(iSize);
    if( NULL == pbyBuf )
    {
        return EMEM_INSUFFICIENT;
    }
    char* pos = pbyBuf;
    int iRead = 0;
    *piBufLen = 0;

    do 
    {
        if(InternetReadFile(hConnection,pos,iSize,(LPDWORD)&iRead))
        {
            pos += iRead;
            iSize -= iRead;
            *piBufLen += iRead;
        }
        else
        {
            break;
        }
        
    }while(iRead > 0);
    char* pbyFile = NULL;
    if(*piBufLen)
    {
        pbyFile = (char*)malloc(*piBufLen);
        if( NULL == pbyFile )
        {
            free(pbyBuf);
            *piBufLen = 0;
            return EMEM_INSUFFICIENT;
        }
        memcpy(pbyFile,pbyBuf,*piBufLen);
    }
    
    free(pbyBuf);
    *ppbyBuf = pbyFile;
    InternetCloseHandle(hConnection); 
    InternetCloseHandle(hSession); 
    return EOK; 
}
