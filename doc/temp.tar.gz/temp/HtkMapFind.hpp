/** @file   HtkMapFind.hpp
*   @note HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
*   @brief 	HtkMapFind
*   @note	
*   <version>       <time>          <author>        <desc>
*      1.0         2015/7/6        zhuweiping          found                                                   
*/
#ifndef _HTK_MAP_FIND_HPP_
#define _HTK_MAP_FIND_HPP_

/**	@fn		template<typename T,class Key, class Value> Value HTK_MapFind(T& t,const Key& k,Value& v)
	@brief	replace the std::map find operation[],bedause the find operation[] will change the map. 
*/
template<typename T,class Key, class Value>
Value& HTK_MapFind(T& t,const Key& k,Value& v){
	T::iterator it = t.find(k);
	if(it != t.end())
		v = it->second;
	return v;
}

#endif