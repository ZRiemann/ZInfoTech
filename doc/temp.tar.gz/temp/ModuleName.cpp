#include "../HtkError.h"
#include "ModuleName.h"

#if (defined(_WIN32) || defined(_WIN32_WCE) || defined(_WIN64))      // toolkit for Windows
#include <Windows.h>
int HTK_ModuleName(char* path, char* name)
{
    char buf[MAX_PATH]; 
    char c;
    char* szDest = NULL;
    ::GetModuleFileNameA(NULL,buf,256);
    szDest = strrchr(buf,'\\');
    if(NULL != szDest)
    {
        c = *(szDest+1);
        *(szDest+1) = '\0';
    }
	else
	{
		return HTK_ENOT_FIND_OBJ;
	}

    if( NULL != path )
    {
        strcpy(path,buf);
    }
    
    *(szDest+1) = c;
    *szDest = '\0';
    if( NULL != name )
    {
        strcpy(name,szDest+1);
    }
    
    return HTK_EOK;
}
#else   // POSIX
#include <stdlib.h> 
#include <unistd.h> 
int HTK_ModuleName(char* path, char* name)
{
    char buf[1024]; 
    char c;
    char* szDest = NULL;
    int rslt = readlink("/proc/self/exe", buf, 1024); 
    if ( rslt < 0 || rslt >= 1024 ) { 
        return HTK_ECALL_FUN_FAIL; 
    } 
    buf[rslt] = '\0'; 
    
    szDest = strrchr(buf,'/');

    if(NULL != szDest)
    {
        c = *(szDest+1);
        *(szDest+1) = '\0';
    }
	else
	{
		return HTK_ENOT_FIND_OBJ;
	}
    if( NULL != path )
    {
        strcpy(path,buf);
    }

    *(szDest+1) = c;
    *szDest = '\0';
    if( NULL != name )
    {
        strcpy(name,szDest+1);
    }

    return HTK_EOK;
}
#endif
