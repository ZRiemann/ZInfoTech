#include "HtkThreadc.h"
#include "../HtkType.h"
#include "../HtkError.h"
#include "../HtkTrace.h"
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <errno.h>
#include <sched.h>

static HTK_THR_ABILITY_E g_enThrAbility = HTK_THR_NOTSUPPORT;

int HTK_ThreadAbility(HTK_THR_ABILITY_E* peAbility)
{
    int ret = HTK_EOK;
    *peAbility = g_enThrAbility;
    if( _POSIX_VERSION < 199506L )
    {
      if( _POSIX_C_SOURCE >= 199506L )
	{
	  HTK_Msg("Not Support Thread.");
	  g_enThrAbility = HTK_THR_NOTSUPPORT;
	}
      else
	{
	  HTK_Msg("Try again with -D_POSIX_C_SOURCE=199506L");
	}
    }
    else
    {
      g_enThrAbility = HTK_THR_ONLYSUPPORT;
      HTK_Msg("Support thread.");
      #ifdef _POSIX_THREAD_PRIORITY_SCHEDULING
      g_enThrAbility = HTK_THR_SUPPORTPRI;
      HTK_Msg("and Thread support priority.");
      #endif
    }
    HTK_Msg("HTK_ThreadAbility(HTK_THR_ABILITY_E*:%d):%d",g_enThrAbility, ret);
  return ret;
}

int HTK_ThreadCreate(fnThrProc fn, HTK_VOIDPTR param, HTK_THR_ID* ulID)
{
  return HTK_ThreadCreatex(fn,param,ulID,NULL);
}

int HTK_ThreadCreateAttr(fnThrProc fn, HTK_VOIDPTR param, HTK_THR_ID* pID, int isDetach, int offsetNormal, HTK_VOIDPTR ctx)
{
  int ret = HTK_EOK;
  pthread_attr_t attr;
  ret = pthread_attr_init(&attr);
  HTK_VERIFY_ERR(0,ret);
  if( 1 == isDetach )
    {
   
     ret = pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);
   }
  else
    {
     ret = pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_JOINABLE);
    }
  if( 0 != offsetNormal )
    {
      int max_priority,min_priority, iPriority;
      struct sched_param sched_p;
      //ret = pthread_attr_setschedpolicy(&attr, SCHED_OTHER);
      ret = pthread_attr_setschedpolicy(&attr, SCHED_FIFO);
      HTK_VERIFY_ERR( 0, ret);
      max_priority = sched_get_priority_max(SCHED_FIFO);
      min_priority = sched_get_priority_min(SCHED_FIFO);
      HTK_MSG("Thread: max_priority=%d, min_priority=%d;",max_priority,min_priority);
      iPriority = ((max_priority + min_priority)>>1) + offsetNormal;
      if(iPriority < min_priority)
	{
	  iPriority = min_priority;
	}
      else if(iPriority > max_priority)
	{
	  iPriority = max_priority;
	}
      sched_p.sched_priority = iPriority;
      ret = pthread_attr_setschedparam(&attr,&sched_p);
      HTK_VERIFY_ERR(0,ret);
      HTK_MSG("Set thread priority to %d.",iPriority);
    }
  HTK_ThreadCreatex(fn,param,pID,&attr);
  pthread_attr_destroy(&attr);
  return ret;
}

int HTK_ThreadCreatex(fnThrProc fn, HTK_VOIDPTR param, HTK_THR_ID* pID, pthread_attr_t* attr)
{
  int ret = HTK_EOK;
  HTK_Msg("HTK_ThreadCreatex(fnThrProc:%08x, HTK_VOIDPTR:%08x, HTK_THR_ID:%08x, pthread_attr_t*:%08x)",fn,param,pID,attr);
  ret = pthread_create((pthread_t*)pID,attr,fn,param);
  if( 0 != ret )
    {
      ret = HTK_ECALL_FUN_FAIL;
      HTK_ERRM(HTK_LastErr(errno));
    }
  HTK_Msg("HTK_ThreadCreatex(HTK_THR_ID:%08x):%d", *pID, ret);
  return ret;
}

int HTK_ThreadExit(HTK_VOIDPTR retval)
{
  pthread_exit(retval);
  HTK_Msg("HTK_ThreadExit(HTK_VOIDPTR:%d)",retval);
  return HTK_EOK;
}

int HTK_ThreadJoin(HTK_THR_ID id, HTK_VOIDPTR* thread_return)
{
  int ret = HTK_EOK;
  HTK_Msg("start HTK_ThreadJoin(HTK_THR_ID:%08x, HTK_VOIDPTR*:%08x)...",id,*thread_return);
  ret = pthread_join(id,thread_return);
  
  if( 0 != ret )
    {
      ret = HTK_ECALL_FUN_FAIL;
      HTK_ERRM(HTK_LastErr(errno));
    }
  HTK_Msg("stop HTK_ThreadJoin(HTK_THR_ID:%08x, HTK_VOIDPTR*:%08x):%d",id,*thread_return,ret);
  return ret;
}

int HTK_ThreadDetach(HTK_THR_ID ulID)
{
  int ret = HTK_EOK;
  
  ret = pthread_detach(ulID);
  if( 0 != ret )
    {
      ret = HTK_ECALL_FUN_FAIL;
      HTK_ERRM(HTK_LastErr(errno));
    }
  HTK_Msg("HTK_ThreadDetach(HTK_THR_ID:%08x):%d",ulID,ret);
  return ret;
}

int HTK_ThreadCancel(HTK_THR_ID thrID)
{
  int iRet = HTK_EOK;
  iRet = pthread_cancel(thrID);
  if( 0 != iRet )
    {
      iRet = HTK_ECALL_FUN_FAIL;
      HTK_ERRM(HTK_LastErr(errno));
    }
  else
    {
      iRet = HTK_EOK;
    }
  return iRet;
}
