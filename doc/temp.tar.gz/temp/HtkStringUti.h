/** @file   HtkStringUti.h
*   @note HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
*   @brief 	HtkStringUti
*   @note	
*   <version>       <time>          <author>        <desc>
*      1.0         2015/7/22        zhuweiping          found                                                   
*/
#ifndef _HTK_STRING_UTIL_H_
#define _HTK_STRING_UTIL_H_

#include <string>
#include <vector>

int HTK_StrSplit(const std::string& strSrc, const std::string& strSplit, std::vector<std::string>& vDest, int flag);// flag = 0 -not clear vDest, flag = 1 - clear vDest
int HTK_StrSplit(const std::string& strSrc, const std::string& strSplit, std::vector<int>& vDest, int flag);

#endif
