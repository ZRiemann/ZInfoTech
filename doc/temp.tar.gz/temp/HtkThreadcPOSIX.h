/**@file HtkThreadc.h
 * @brief C mode thread wrapper 
 * @note
 * CAUTION: CC FLAGE must use -lpthread and -D_REENTRANT
 * <version>  <author>   <date>     <history>
 * v1.0       zhuweiping 2015-05-09 found
 */
#ifndef _HTK_THREAD_C_H_
#define _HTK_THREAD_C_H_

#ifdef __cplusplus
extern "C"{
#endif

#include "../HtkType.h"
#include "../thread/HtkThreadDefs.h"
#include <pthread.h>

int HTK_ThreadAbility(HTK_THR_ABILITY_E* peAbility);
int HTK_ThreadCreate(fnThrProc fn, HTK_VOIDPTR param, HTK_THR_ID* ulID);
// isDetach-1(detached)/0(joined)
// aboveNomal = ((max+min)>>1)+aboveNormal, if(out of range){use max/min}
int HTK_ThreadCreateAttr(fnThrProc fn, HTK_VOIDPTR param, HTK_THR_ID* ulID, int isDetach, int aboveNormal, HTK_VOIDPTR ctx);
int HTK_ThreadCreatex(fnThrProc fn, HTK_VOIDPTR param, HTK_THR_ID* ulID, pthread_attr_t* attr);
int HTK_ThreadExit(HTK_VOIDPTR retval);
int HTK_ThreadJoin(HTK_THR_ID ulID, HTK_VOIDPTR* thread_return);
int HTK_ThreadDetach(HTK_THR_ID ulID);
//pthread_exit(); // must use pthread_exit(), not use return in fnThrProc.
//pthread_cancel(); // cancel a thread
int HTK_ThreadCancel(HTK_THR_ID thrID);

#ifdef __cplusplus
}
#endif

#endif/*_HTK_THREAD_C_H_*/

#if 0
int pthread_attr_init(pthread_attr_t* attr);
int pthread_attr_destroy(pthread_attr_t* attr);

int pthread_attr_setdetachstate(pthread_attr_t* attr, int detachstate);//PTHREAD_CREATE_DETACHED/JOINABLE
int pthread_attr_getdetachstate(pthread_attr_t *attr, int *detachstate);

int pthread_attr_setschedpolicy(pthread_attr_t *attr, int policy);// SCHED_FIFO/RR/OTHER
int pthread_attr_getschedpolicy(pthread_attr_t *attr, int *policy);

//...
#endif
