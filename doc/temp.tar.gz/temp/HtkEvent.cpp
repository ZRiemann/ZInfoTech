/** @file   HtkEvent.cpp
*   @note HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
*   @brief 	�¼���װ��ʵ��

*   @author	Zhu Weiping
*   @date   2015/3/24

*   @note	
*/
#pragma warning(disable:4800)

#include <htk/thread/htkevent.h>
#include <htk/HtkTrace.h>
CHtkEvent::CHtkEvent(bool manual, bool state,const char* name)
{
    m_handle = CreateEventA(0,manual,state,name);
    if(NULL == m_handle)
    {
        //LASTERR();
    }
}
CHtkEvent::~CHtkEvent()
{
    CLOSE_HANDLE(m_handle);
}

/** @fn		bool Set(bool state)
*   @brief 	�����¼�״̬
*   @param	bool state [IN] �¼�״̬
*	@return	true:�ɹ���false:ʧ��
*/
bool CHtkEvent::Set(bool state)
{
    bool ret = true;
    if(state)
    {
        ret = (bool)SetEvent(m_handle);
    }
    else
    {
        ret = (bool)ResetEvent(m_handle);
    }
    if(!ret)
    {
        //LASTERR();
    }
    return ret;
}

/** @fn		bool Pulse()
*   @brief 	�����¼�״̬
*	@return	true:�ɹ���false:ʧ��
*/
bool CHtkEvent::Pulse()
{
    bool ret = (bool)PulseEvent(m_handle);
    if(!ret)
    {
        //LASTERR();
    }
    return ret;
}