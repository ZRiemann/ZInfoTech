/** @file   HtkMapErase.hpp
*   @note HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
*   @brief 	HtkMapErase
*   @note	
*   <version>       <time>          <author>        <desc>
*      1.0         2015/7/6        zhuweiping          found                                                   
*/
#ifndef _HTK_MAP_ERASE_HPP_
#define _HTK_MAP_ERASE_HPP_

/**	@fn		template<typename T,class Key>  bool HTK_MapErase(T& t,const Key& k)
	@brief	erase map item safely
*/
template<typename T,class Key>
 bool HTK_MapErase(T& t,const Key& k){
	bool ret = false;
	T::iterator it = t.find(k);
	if(it != t.end()){
		t.erase(it);
		ret = true;
	}
	return ret;
}

#endif