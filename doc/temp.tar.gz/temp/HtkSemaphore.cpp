/** @file   HtkSemaphore.cpp
*   @note HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
*   @brief 	�ź�����װ��ʵ��

*   @author	Zhu Weiping
*   @date   2015/3/24

*   @note	
*/
#include "../thread/HtkSemaphore.h"
#include "../HtkTrace.h"
#include "../HtkError.h"


CHtkSemaphore::CHtkSemaphore(int init,int max)
{
    if( NULL == ( m_imp =::CreateSemaphoreA(NULL,init,max,NULL)) )
    {
        HTK_ERRF(HTK_LastErr(GetLastError()));
    }
}
CHtkSemaphore::CHtkSemaphore(int init, int max,const char* name)
{
    if( NULL == ( m_imp =::CreateSemaphoreA(NULL,init,max,name)) )
    {
        HTK_ERRF(HTK_LastErr(GetLastError()));
    }
}
CHtkSemaphore::~CHtkSemaphore()
{
    if( m_imp )
    {
        CloseHandle( m_imp );
    }
}

/** @fn		int Wait(unsigned long& r, int tmout = 0)
*   @brief 	�ȴ�һ���ź�����Դ
*   @param  int tmout = 0 [IN] ��ʱ�¼� ��λ��ms
*	@return	EOK/����������	
*/
int CHtkSemaphore::Wait(int tmout)
{
    if( NULL == m_imp){
        return HTK_ENULL_HANDLE;
    }
    if( -1 == tmout )
    {
        tmout = INFINITE;
    }
    DWORD dwWait = ::WaitForSingleObject(m_imp,tmout);
    if( WAIT_FAILED == dwWait)
    {
        HTK_ERRF(HTK_LastErr(GetLastError()));
        return HTK_ECALL_FUN_FAIL;
    }
    else if( WAIT_TIMEOUT == dwWait )
    {
        if( tmout == 0 )
        {
            return HTK_EAGAIN;
        }
        else
        {
            return HTK_ETIME_OUT;
        }
    }
    return HTK_EOK;
}

/** @fn		int Post(int count = 1)
*   @brief 	����count���ź�����Դ
*   @param	int count = 1 [IN] �ź�����Դ����
*	@return	EOK/����������	
*/
int CHtkSemaphore::Post(int count)
{
    if( NULL == m_imp)
    {
        return HTK_ENULL_HANDLE;
    }
    long precnt;
    if(::ReleaseSemaphore( m_imp, count, &precnt))
    {
        return HTK_EOK;
    }
    HTK_ERRF(HTK_LastErr(GetLastError()));
    return HTK_EFAIL;
}
