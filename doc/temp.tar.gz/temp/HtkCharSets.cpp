#include <Windows.h>
#include <htk/utility/HTKCharSets.h>

/** @fn		std::wstring HTK_S2ws(const std::string& src,unsigned int src_code_page)
*   @brief 	��string תΪ wstring
*   @param	const std::string& src      [IN] Դ�ַ���
*   @param  unsigned int src_code_page  [IN] Դ�ַ��������ʽ
*	@return	wstring
*   @note
*   CP_ACP ANSI code page 
*   CP_MACCP Macintosh code page 
*   CP_OEMCP OEM code page 
*   CP_SYMBOL Windows 2000/XP: Symbol code page (42) 
*   CP_THREAD_ACP Windows 2000/XP: Current CHtkThread's ANSI code page 
*   CP_UTF7 
*   CP_UTF8 
*/
std::wstring HTK_S2ws(const std::string& src,unsigned int src_code_page){ 
	wchar_t *  pwchar;
	int  len;
	len = MultiByteToWideChar( src_code_page,0,src.c_str(),-1,NULL,0 );
	len++;
	pwchar = new  (std::nothrow)wchar_t[len];  
	memset((void*)pwchar,0,(len)*sizeof(wchar_t));
    if( NULL == pwchar )
    {
        return NULL;
    }
	::MultiByteToWideChar( src_code_page,0,src.c_str(),-1,(LPWSTR)pwchar,len );  
	std::wstring  wstr;  
	wstr = pwchar;
	delete[]  pwchar; 
	return  wstr;  
}

// CAUTION: �����˹���wchar_t���ַ���
wchar_t* HTK_S2ws1(const char* src, unsigned int src_code_page)
{
    wchar_t *  pwchar;
    int  len;
    len = MultiByteToWideChar( src_code_page,0,src,-1,NULL,0 );
    len++;
    pwchar = new  (std::nothrow)wchar_t[len];
    if( NULL == pwchar )
    {
        return NULL;
    }
    memset((void*)pwchar,0,(len)*sizeof(wchar_t));  
    MultiByteToWideChar( src_code_page,0,src,-1,(LPWSTR)pwchar,len );    
 
    //delete[]  pwchar; 
    return  pwchar;  
}

/** @fn		std::string HTK_Ws2s(const std::wstring& src,unsigned int dest_code_page)
*   @brief 	��wstring תΪ string
*   @param	const std::wstring& src      [IN] Դ�ַ���
*   @param  unsigned int src_code_page  [IN] Ŀ���ַ��������ʽ
*	@return	string
*/
std::string HTK_Ws2s(const std::wstring& src,unsigned int dest_code_page){
	char*     pchar;
	int    len;
	len = WideCharToMultiByte(dest_code_page,0,src.c_str(),-1,NULL,0,NULL,NULL);
	len++;
	pchar = new (std::nothrow)char[len];
	memset((void*)pchar, 0, sizeof(char) * (len));
	WideCharToMultiByte(dest_code_page,0,src.c_str(),-1,pchar,len,NULL,NULL);
	std::string str;
	str = pchar;
	delete[] pchar;
	return str;
}

char* HTK_Ws2s1(const wchar_t* src, unsigned int dest_code_page)
{
    char*     pchar;
    int    len;
    len = WideCharToMultiByte(dest_code_page,0,src,-1,NULL,0,NULL,NULL);
    len++;
    pchar = new (std::nothrow)char[len];
    memset((void*)pchar, 0, sizeof(char) * (len));
    WideCharToMultiByte(dest_code_page,0,src,-1,pchar,len,NULL,NULL);
    return pchar;
}

/** @fn		std::string HTK_ChangeCharSet(const std::string& src,unsigned int dest_code_page, unsigned int src_code_page);
*   @brief 	ת��string�ַ����ı����ʽ
*   @param	const std::string& src [IN] Դ�ַ���
*   @param  unsigned int dest_code_page [IN] Ŀ���ַ��������ʽ
*   @param  unsigned int src_code_page [IN] Դ�ַ��������ʽ
*	@return	EOK/����������	
*/
std::string HTK_ChangeCharSet(const std::string& src,unsigned int dest_code_page, unsigned int src_code_page){
	return HTK_Ws2s(HTK_S2ws(src,src_code_page),dest_code_page);
}