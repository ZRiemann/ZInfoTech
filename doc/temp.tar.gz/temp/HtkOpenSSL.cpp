#include "HtkOpenSSL.h"
//#include <openssl/ssl.h>
#include <openssl/pem.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include "../../HtkError.h"
#include "../../HtkTrace.h"
#include "../../utility/HtkFile.h"

#pragma comment(lib,"libeay32")

const char* CHtkOpenSSL::PEM_PUB_BEGIN = "-----BEGIN PUBLIC KEY-----\n";   // PEM��ʽ ��Կͷ
const char* CHtkOpenSSL::PEM_PUB_END = "\n-----END PUBLIC KEY-----\n";     // PEM��ʽ ��Կβ
const char* CHtkOpenSSL::PEM_PRI_BEGIN = "-----BEGIN RSA PRIVATE KEY-----\n";  // PEM��ʽ ��Կͷ
const char* CHtkOpenSSL::PEM_PRI_END = "\n-----END RSA PRIVATE KEY-----\n";    // PEM��ʽ ��Կβ

CHtkOpenSSL::CHtkOpenSSL()
:m_rsaLocalKey(NULL),m_rsaRemoteKey(NULL)
{

}
CHtkOpenSSL::~CHtkOpenSSL()
{
    if(NULL != m_rsaLocalKey)
    {
        RSA_free(m_rsaLocalKey);
        m_rsaLocalKey = NULL;
    }
    if(NULL != m_rsaRemoteKey)
    {
        RSA_free(m_rsaRemoteKey);
        m_rsaRemoteKey = NULL;
    }
}

/** @fn		int RSAGenerateKey(int bits)
*   @brief 	���ɱ���RSA��Կ��˽Կ
*   @param  int bits            [IN]    ��Կ����
*	@return	EOK/����������	
*/
int CHtkOpenSSL::RSAGenerateKey(int bits)
{
    if( (bits < 256) || (bits > 1024*1024) )
    {
        return EPARAM_INVALID;
    }
    unsigned long e = RSA_F4;
    //e = RSA_3;
    m_rsaLocalKey = RSA_generate_key(bits,e,NULL,NULL);
    HTK_VERIFY_EQUAL(NULL,m_rsaLocalKey,ECALL_FUN_FAIL);
    return EOK;
}

/** @fn		int RSASetKey(KEY_TYPE enType, const char* szKey)
*   @brief 	������Կ
*   @param  KEY_TYPE enType     [IN]    ��Կ����
*   @param  const char* szKey   [OUT]   ��Կ�ַ���
*	@return	EOK/����������	
*/
int CHtkOpenSSL::RSASetKey(KEY_TYPE enType, const char* szKey)
 {
    if( NULL == szKey || ( enType != LOCAL_PRI_KEY && enType != LOCAL_PUB_KEY && enType != REMOTE_PUB_KEY ))
    {
        return EPARAM_INVALID;
    }
    
    int ret = EOK;
    BIO* bio = BIO_new(BIO_s_mem());
    HTK_VERIFY_EQUAL(NULL, bio, EMEM_INSUFFICIENT);
    if( 0 >= BIO_write(bio,szKey,strlen(szKey)) )
    {
        ERRC(ECALL_FUN_FAIL);
        BIO_free(bio);
        return ECALL_FUN_FAIL;
    }
    switch(enType)
    {
    case LOCAL_PUB_KEY:     ///< ���ع�Կ
        ret = ENOT_SUPPORT;
        break;
    case LOCAL_PRI_KEY:     ///< ����˽Կ
        ret = ENOT_SUPPORT;
        break;
    case REMOTE_PUB_KEY:    ///< �Զ˹�Կ
    //do{
        //m_rsaRemoteKey = PEM_read_bio_RSAPublicKey(bio, NULL, NULL, NULL);
        m_rsaRemoteKey = PEM_read_bio_RSA_PUBKEY(bio, NULL, NULL, NULL);
        if( NULL == m_rsaRemoteKey )
        {
            ret = ECALL_FUN_FAIL;
        }
    //}while(0);
        break;
    default:
        ret = EPARAM_INVALID;
        ERRF(HTK_StrErr(ret));
        break;
    }
    BIO_free(bio);

    return ret;
}

/** @fn		int RSASaveKey(KEY_TYPE enType, const char* szFile)
*   @brief 	������Կ���ļ�
*   @param	KEY_TYPE enType     [IN]    ��Կ����
*   @param  const char* szFile  [OUT]   �ļ���
*	@return	EOK/����������	
*/
int CHtkOpenSSL::RSASaveKey(KEY_TYPE enType, const char* szFile)
{
    int iRet = EOK;
    FILE* pf = NULL;
    pf = fopen(szFile,"wb");
    if( NULL != pf)
    {
        if(0 == PEM_write_RSA_PUBKEY(pf,m_rsaLocalKey))
        {
            iRet = ECALL_FUN_FAIL;
        }
        fclose(pf);
    }
    else
    {
        iRet = ECALL_FUN_FAIL;
    }
    if( EOK != iRet )
    {
        ERRC(iRet);
    }
    return iRet;
}

/** @fn		int RSALoadKey(KEY_TYPE enType, const char* szFile)
*   @brief 	���ļ���ȡ��Կ
*   @param	KEY_TYPE enType     [IN]    ��Կ����
*   @param  const char* szFile  [IN]    �ļ���
*	@return	EOK/����������	
*/
int CHtkOpenSSL::RSALoadKey(KEY_TYPE enType, const char* szFile)
{
    int iRet = EOK;
    FILE* pf = NULL;
    pf = fopen(szFile,"rb");
    if( NULL != pf)
    {
        m_rsaRemoteKey = PEM_read_RSA_PUBKEY(pf,NULL, NULL, NULL);
        if( NULL == m_rsaRemoteKey )
        {
            iRet = ECALL_FUN_FAIL;
        }
        fclose(pf);
    }
    else
    {
        iRet = ECALL_FUN_FAIL;
    }
    if( EOK != iRet )
    {
        ERRC(iRet);
    }
    return iRet;
}

/** @fn		int Codec(KEY_TYPE enType, OP_CODEC, const char* byIn, int iIn, char* byOut, int* iOut)
*   @brief 	�ӽ����ڴ�����,RSA_PKCS1_PADDING
*   @param	KEY_TYPE enType     [IN]    ��Կ����
*   @param  OP_CODEC enOp       [IN]    ��������
*   @param  const char* byIn    [IN]    ����������
*   @param  int iIn             [IN]    ���������ݳ���
*   @param  char* byOut         [OUT]   ���ܺ�����
*   @param  int* iOut           [IN|OUT]   ���ܺ����ݳ���
*	@return	EOK/����������
*   @note   �ӽ�����Ϣ���ڴ�ռ����û����з������
*   ����1��Ԥ�Ȼ�ȡ�ӽ������������ڴ��С��byOut����ΪNULL�����ú� iOut ָʾ�ӽ��ܺ������ڴ�ռ�
*   ����2�����䲽��1)iOut��С���ڴ�ռ�byBuf��Ȼ��byBuf��ΪbyOut�����������
*/
int CHtkOpenSSL::Codec(KEY_TYPE enType, OP_CODEC enOp, const char* byIn, int iIn, char* byOut, int* iOut)
{
    if( (NULL == byIn) || (NULL == iOut) || (0 == iIn))
    {
        return EPARAM_INVALID;
    }
    int ret = EOK;
    RSA* pRsa = NULL;
    int iRSASize = 0;
    int iBlockSize = 0;
    int iBlockNum = 0;
    int iOutSize = 0;
    bool bPubKey = false;
    switch(enType)
    {
    case REMOTE_PUB_KEY:
        bPubKey = true;
        pRsa = m_rsaRemoteKey;
        break;
    case LOCAL_PRI_KEY:
        bPubKey = false;
        pRsa = m_rsaLocalKey;
        break;
    case LOCAL_PUB_KEY:
         bPubKey = true;
         pRsa = m_rsaLocalKey;
        break;
    default:
        return EPARAM_INVALID;
    }
    HTK_VERIFY_EQUAL(NULL, pRsa, EPARAM_INVALID);
    iRSASize = RSA_size(pRsa);                                    // RSA���ܵ�λ��С
    int iRemainder = iIn;
    int iLen = 0;
    int iRet = 0;
    char* byOutPos = byOut;
    const char* byInPos = byIn;

    iBlockSize = iRSASize;
    if(OP_ENCODE == enOp )
    {
        iBlockSize -= RSA_PKCS1_PADDING_SIZE; // RSA�ְ���С
    }
    iBlockNum = iIn/iBlockSize;                     // �ְ���
    if( 0 != (iIn%iBlockSize) )
    {
        ++iBlockNum;
    }
    iOutSize = iBlockNum*iRSASize;                  // ������������ռ�
    if( NULL == byOut )
    {   // ��ѯ����ռ�
        *iOut = iOutSize;
        return EOK;                                 // ���ؼ������ݴ�С
    }
    if( (NULL != byOut) && (*iOut < iOutSize) )
    {   // �����ڴ�ռ䲻��
        return EPARAM_INVALID;
    }
    *iOut = 0;                                      // ����
    if( OP_ENCODE == enOp )
    {
        while( iRemainder > 0)
        {
            iLen = (iRemainder > iBlockSize) ? iBlockSize : iRemainder;
            if(bPubKey)
            {
                iRet = RSA_public_encrypt(iLen, (const unsigned char*)byInPos, (unsigned char*)byOutPos, pRsa, RSA_PKCS1_PADDING);
            }
            else
            {
                iRet = RSA_private_encrypt(iLen, (const unsigned char*)byInPos, (unsigned char*)byOutPos, pRsa, RSA_PKCS1_PADDING);
            }
            if( iRet <= 0)
            {
                return ECALL_FUN_FAIL;
            }
            *iOut += iRet;
            byOutPos += iRet;
            byInPos += iLen;
            iRemainder -= iLen;
        }
    }
    else if( OP_DECODE == enOp )
    {
        while( iRemainder > 0)
        {
            iLen = (iRemainder > iBlockSize) ? iBlockSize : iRemainder;
            if(bPubKey)
            {
                iRet = RSA_public_decrypt(iLen, (const unsigned char*)byInPos, (unsigned char*)byOutPos, pRsa, RSA_PKCS1_PADDING);
            }
            else
            {
                iRet = RSA_private_decrypt(iLen, (const unsigned char*)byInPos, (unsigned char*)byOutPos, pRsa, RSA_PKCS1_PADDING);
            }
            if( iRet <= 0)
            {
                return ECALL_FUN_FAIL;
            }
            *iOut += iRet;
            byOutPos += iRet;
            byInPos += iLen;
            iRemainder -= iLen;
        }
    }
    else
    {
        ret = EPARAM_INVALID;
        ERRF(HTK_StrErr(ret));
    }
    return ret;
}

/** @fn		int Md5(const char* byIn,int iIn,  char* byOut, int* iOut)
*   @brief 	�����ݽ���MD5����
*   @param	const char* byIn    [IN]    ����������
*   @param  int iIn             [IN]    ���������ݳ���
*   @param  char* byOut         [OUT]   MD5��
*   @param  int iOut            [IN]    MD5�볤��
*	@return	EOK/����������	
*/
int CHtkOpenSSL::Md5(const char* byIn,int iIn,  char* byOut, int iOut)
{
    if( (NULL == byIn) || (0 == iIn) || (NULL == byOut) || ( iOut < MD5_SIZE ) )
    {
        return EPARAM_INVALID;
    }
    int i;
    MD5_CTX ctxMd5;
    unsigned char byTemp[20];
    MD5_Init(&ctxMd5);  
    MD5_Update(&ctxMd5, (void*)(byIn), iIn);   
    MD5_Final(byTemp, &ctxMd5);  

    const int MD5_BYTES = 16;
    for(i = 0; i < MD5_BYTES; i++)
    {
        sprintf(byOut+(i<<1),"%02X",byTemp[i]);
    }
    
    return EOK;
}

/** @fn		int PEMStr(KEY_TYPE enType, char* szPEM, int* iPEM)
*   @brief 	���PEM��ʽ��Կ
*   @param	KEY_TYPE enType     [IN]    ��Կ����
*   @param  char* szPEM         [OUT]   PEM��Կ�ַ���
*   @param  int* iPEM           [IN|OUT]PEM�ַ�������
*	@return	EOK/����������
*   @note   if(szPEM = NULL){���� iPEM ֵָʾ����ռ��С} 
*/
int CHtkOpenSSL::PEMStr(KEY_TYPE enType, char* szPEM, int* iPEM)
{
    if( (NULL == szPEM) || ( NULL == iPEM) )
    {
        return EPARAM_0_POINTER;
    }
    int ret = EOK;
    int len = 0;
    BIO* bio = BIO_new(BIO_s_mem());
    HTK_VERIFY_EQUAL(NULL, bio, EMEM_INSUFFICIENT);

    switch(enType)
    {
    case LOCAL_PRI_KEY:
        PEM_write_bio_RSAPrivateKey(bio, m_rsaLocalKey, NULL, NULL, 0, NULL, NULL);
        break;
    case LOCAL_PUB_KEY:
        //PEM_write_bio_RSAPublicKey(bio,m_rsaLocalKey);
        PEM_write_bio_RSA_PUBKEY(bio,m_rsaLocalKey);
        break;
    case REMOTE_PUB_KEY:
        //PEM_write_bio_RSAPublicKey(bio,m_rsaRemoteKey);
        PEM_write_bio_RSA_PUBKEY(bio,m_rsaRemoteKey);
        break;
    default:
        ret = ENOT_SUPPORT;
        break;
    }
    if( EOK == ret)
    {
        len = BIO_ctrl_pending(bio);
        if( NULL == szPEM )
        {
            *iPEM = len;                // ������Կ�ַ�����С
        }
        else if( (NULL != szPEM) && (*iPEM < len+1) )
        {
            ret = EPARAM_INVALID;       // �ַ����������ռ䲻��
        }
        else if( (NULL != szPEM) && (*iPEM > len) )
        {                               // ������Ӧ�ַ���
            BIO_read(bio,szPEM,len);
            szPEM[len] = 0;
        }
    }

    BIO_free(bio);
    return ret;
}

/** @fn		int PEMFormet(std::string& strKey, bool bPubKey, bool bAdd)
*   @brief 	����Կ�ַ������ӻ�ɾ��ͷβ�ַ���
*   @param	std::string& strKey ��Կ�ַ���
*   @param  bool bPubKey �Ƿ�Ϊ��Կ����
*   @param  bool bAdd [IN] true ����ͷβ �� false ɾ��ͷβ
*	@return	HTK_EOK/HTK_E*
*	@note
*/
int CHtkOpenSSL::PEMFormet(std::string& strKey, bool bPubKey, bool bAdd)
{
    int ret = EOK;

    if(bAdd)
    {   // ����ͷβ
        for(unsigned int i = 64; i < strKey.size(); i+=64)
        {
            if(strKey[i] != '\n')
            {
                strKey.insert(i, "\n");
            }
            i++;
        }
        if(strKey.at(strKey.size()-1) == '\n')
        {   // ȥ�����һ��\n,����������β����\n �ظ�
            strKey.replace(strKey.size()-1,1,"");
        }
        if(bPubKey)
        {
            
            strKey.insert(0, PEM_PUB_BEGIN);
            strKey.append(PEM_PUB_END);
        }
        else
        {
            strKey.insert(0, PEM_PRI_BEGIN);
            strKey.append(PEM_PRI_END);
        }
    }
    else
    {   // ȥ��ͷβ
        
        if(bPubKey)
        {
            strKey.replace(0,strlen(PEM_PUB_BEGIN),"");
            strKey.replace(strKey.rfind(PEM_PUB_END),strlen(PEM_PUB_END),"");
        }
        else
        {
            strKey.replace(0,strlen(PEM_PRI_BEGIN),"");
            strKey.replace(strKey.rfind(PEM_PRI_END),strlen(PEM_PUB_END),"");
        }
        int pos = -1;
        while( -1 != (pos = strKey.find('\n')) )
        {
            strKey.replace(pos,1,"");
        }
    }
    return ret;
}