#include "../HtkTrace.h"
#include "HtkSemaphorec.h"
#include <errno.h>
#include <time.h>

int HTK_SemInit(sem_t* sem, int pshared, HTK_UINT value)
{
  int ret = HTK_EOK;
  ret = sem_init(sem, pshared, value);
  if( 0 != ret )
  {
    ret = HTK_ECALL_FUN_FAIL;
    HTK_ERRM(HTK_LastErr(errno));
  }
  else
  {
    HTK_Msg("HTK_SemInit(sem_t*:%p)",sem);
  }
  return ret;
}
int HTK_SemWait(sem_t* sem)
{
  int iRet = 0; 
  while( (-1 == (iRet = sem_wait(sem))) && (errno == EINTR))
    {
      continue;
    }
  if(-1 == iRet)
    {
      HTK_ERRF(HTK_LastErr(errno));
      iRet = HTK_ECALL_FUN_FAIL;
    }
  return iRet;
}
//int HTK_SemPost(sem_t* sem);
int HTK_SemDestroy(sem_t* sem)
{
  int ret = HTK_EOK;
  if( 0 != sem_destroy(sem) )
  {
    ret = HTK_ECALL_FUN_FAIL;
    HTK_ERRM(HTK_LastErr(errno));
  }
  else
    {
      HTK_Msg("HTK_SemDestroy(sem_t*:%p)",sem);
    }

  return ret;
}
int HTK_SemTryWait(sem_t* sem)
{
    int iRet = HTK_EOK;
    while( (iRet = sem_trywait(sem)) == -1 && errno == EINTR )
        continue;
    if( iRet == -1  )
    {
        if( errno == EAGAIN )
        {
            iRet = HTK_EAGAIN;
        }
        else
        {
	    HTK_ERRF(HTK_LastErr(errno));
            iRet = HTK_ECALL_FUN_FAIL;
        }
    }
    return iRet;
}
int HTK_SemGetValue(sem_t* sem, int* sval)
{
  return sem_getvalue(sem,sval);
}

int HTK_SemTimedWait(sem_t* sem, const struct timespec* abs_timeout)
{
    struct timespec ts;
    int iRet = HTK_EOK;
    
    if( clock_gettime(CLOCK_REALTIME,&ts) == -1 )
    {
      HTK_ERRC(HTK_ECALL_FUN_FAIL);
      return HTK_ECALL_FUN_FAIL;
    }
   
    if(ts.tv_sec > abs_timeout->tv_sec)
    {// abs_timeout not since 1970-1-1 00:00:00, and is abstract seconds
      //HTK_Dbg("sec:%d , nsec:%d",ts.tv_sec,ts.tv_nsec);
      ts.tv_sec += abs_timeout->tv_sec;
      ts.tv_nsec += abs_timeout->tv_nsec;
      ts.tv_sec += (ts.tv_nsec/999999999);
      ts.tv_nsec %= 999999999;
      //HTK_Dbg("sec:%d , nsec:%d",ts.tv_sec,ts.tv_nsec);
    }

    while( (iRet = sem_timedwait(sem, &ts)) == -1 && errno == EINTR )
        continue;
    if( iRet == -1  )
    {
        if( errno == ETIMEDOUT )
        {
            iRet = HTK_ETIME_OUT;
        }
        else
        {
	    HTK_ERRF(HTK_LastErr(errno));
            iRet = HTK_ECALL_FUN_FAIL;
        }
    }
    return iRet;
}
